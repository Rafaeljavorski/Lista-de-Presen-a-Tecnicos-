# Dashboard Tecnicos

Abra o index.html no navegador. Suba este arquivo no GitHub Pages (branch main, pasta root).